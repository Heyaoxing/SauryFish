﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SauryFish.Dto
{
    public class DescriptDto
    {
        public int EnrollNumber { set; get; }
        public string Name { set; get; }
        public string State { set; get; }
        public string Date { set; get; }
        public string Time { set; get; }
    }
}
