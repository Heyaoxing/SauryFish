﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SauryFish.Dto
{
    public class RecordDto
    {
        public int EnrollNumber { set; get; }
        public string Name { set; get; }
        public DateTime AttendancedOn { set; get; }
    }
}
