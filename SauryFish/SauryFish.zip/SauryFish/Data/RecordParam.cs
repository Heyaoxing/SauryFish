﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SauryFish.Data
{
    public class RecordParam
    {
        public string Search { set; get; }
        public int PageIndex { set; get; }
        public int PageSize { set; get; }
    }
}
